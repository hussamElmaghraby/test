class HomeEvent {}

class IncrementEvent extends HomeEvent {}
